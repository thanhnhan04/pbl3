﻿using System;
using System.Collections.Generic;

namespace WebApplication5.Models;

public partial class Congviec
{
    public string MaCongViec { get; set; } = null!;

    public string? ChiTietCongViec { get; set; }

    public TimeSpan? CaLam { get; set; }

    public virtual CongviecNv? CongviecNv { get; set; }
}

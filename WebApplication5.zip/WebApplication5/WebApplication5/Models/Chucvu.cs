﻿using System;
using System.Collections.Generic;

namespace WebApplication5.Models;

public partial class Chucvu
{
    public string MaChucVu { get; set; } = null!;

    public string? ChucVu1 { get; set; }

    public virtual ICollection<Hoso> Hosos { get; set; } = new List<Hoso>();
}

﻿using System;
using System.Collections.Generic;

namespace WebApplication5.Models;

public partial class Phanquyen
{
    public string MaPhanQuyen { get; set; } = null!;

    public string? PhanQuyen1 { get; set; }

    public virtual ICollection<Nhanvien> Nhanviens { get; set; } = new List<Nhanvien>();
}

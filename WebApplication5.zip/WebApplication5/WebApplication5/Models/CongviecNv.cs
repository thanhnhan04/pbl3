﻿using System;
using System.Collections.Generic;

namespace WebApplication5.Models;

public partial class CongviecNv
{
    public string MaCongViec { get; set; } = null!;

    public string? MaNv { get; set; }

    public DateTime? NgayLam { get; set; }

    public bool? ChamCong { get; set; }

    public int? NghiPhep { get; set; }

    public virtual Congviec MaCongViecNavigation { get; set; } = null!;

    public virtual Nhanvien? MaNvNavigation { get; set; }
}

﻿using Microsoft.Data.SqlClient;
using WebApplication5.Models;

namespace WebApplication5
{
    public class UserService
    {
        public LuongNv GetLuongNv()
        {
            LuongNv user = null;
            DataProvider data = new DataProvider();
            string query = "SELECT L.[Luong Co Ban],L.[Phu Cap],LNV.[Ma Luong],LNV.Thang, LNV.[Ngay Cong],LNV.Thuong,LNV.Phat,LNV.[Luong Tong] FROM LuongNV AS LNV " +
                "INNER JOIN Luong AS L ON L.[Ma Luong] = LNV.[Ma Luong]" +
                "WHERE LNV.[Ma NV] = 'NV102'";
            SqlDataReader reader = data.ExecuteReader(query);
            if (reader.Read())
            {
                user = new LuongNv();
           
                user.MaLuong = reader["Ma Luong"].ToString();
                user.Luongcoban = Convert.ToDecimal(reader["Luong Co Ban"].ToString());
                user.NgayCong = Convert.ToInt16(reader["Ngay Cong"].ToString());
                user.Thang = Convert.ToInt16(reader["Thang"].ToString());
                user.Phucap = Convert.ToDecimal(reader["Phu Cap"].ToString());
                user.Thuong = Convert.ToDecimal(reader["Thuong"].ToString());
                user.Phat = Convert.ToDecimal(reader["Phat"].ToString());
                user.LuongTong = Convert.ToDecimal(reader["Luong Tong"].ToString());
            }
 
            return user;
        }
    }
}

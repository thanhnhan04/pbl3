﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace XMLTreeViewApp
{
    public partial class Form1 : Form
    {
        private XmlDocument xmlDoc;
        private string xmlFilePath;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML Files (*.xml)|*.xml";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                xmlFilePath = openFileDialog.FileName;
                xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFilePath);
                PopulateTreeView(xmlDoc.DocumentElement, treeView1.Nodes);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (xmlDoc != null && xmlFilePath != null)
            {
                xmlDoc.Save(xmlFilePath);
                MessageBox.Show("XML file saved successfully.");
            }
            else
            {
                MessageBox.Show("No XML file loaded.");
            }
        }

        private void PopulateTreeView(XmlNode xmlNode, TreeNodeCollection treeNodes)
        {
            foreach (XmlNode node in xmlNode.ChildNodes)
            {
                TreeNode newTreeNode = treeNodes.Add(node.Name);
                PopulateTreeView(node, newTreeNode.Nodes);
            }
        }

        // Add, Edit, Delete, Find functionalities can be implemented similarly.

        // Example of adding a node:
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (xmlDoc != null && treeView1.SelectedNode != null)
            {
                string nodeName = "NewNode";
                XmlNode selectedXmlNode = xmlDoc.SelectSingleNode(treeView1.SelectedNode.FullPath);
                XmlNode newNode = xmlDoc.CreateElement(nodeName);
                selectedXmlNode.AppendChild(newNode);
                treeView1.SelectedNode.Nodes.Add(nodeName);
            }
            else
            {
                MessageBox.Show("No XML file loaded or no node selected.");
            }
        }
    }
}
